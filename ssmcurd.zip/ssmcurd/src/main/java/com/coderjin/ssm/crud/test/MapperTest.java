package com.coderjin.ssm.crud.test;

import java.util.UUID;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.coderjin.ssm.crud.bean.Department;
import com.coderjin.ssm.crud.bean.Employee;
import com.coderjin.ssm.crud.dao.DepartmentMapper;
import com.coderjin.ssm.crud.dao.EmployeeMapper;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:applicationContext.xml"})
public class MapperTest {
	
	@Autowired
	DepartmentMapper departmentMapper;
	
	@Autowired
	EmployeeMapper employeeMapper;
	
	@Autowired
    SqlSession sqlSession;
	
	@Test
	public void testCRUD() {
		System.out.println(employeeMapper);
		
		//departmentMapper.insertSelective(new Department(null,"test"));
		//departmentMapper.insertSelective(new Department(null,"test2"));
		
//	public Employee(Integer empId, String empName, String gender, String email, Integer dId, Department department) {
		
		//employeeMapper.insertSelective(new Employee(null,"hahah","��","111@qq.com",1));
		
		
//		EmployeeMapper mapper = sqlSession.getMapper(EmployeeMapper.class);
//		for (int i = 0; i < 1000; i++) {
//			String uuid = UUID.randomUUID().toString().substring(0, 5)+i;
//			mapper.insert(new Employee(null,uuid,"��",uuid+"@qq.com",1));
//		}
//		
		
		
	}

}
