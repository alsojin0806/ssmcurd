package com.coderjin.ssm.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.coderjin.ssm.crud.bean.Employee;
import com.coderjin.ssm.crud.bean.Msg;
import com.coderjin.ssm.crud.service.EmployeeService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;



@Controller
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	
	 @RequestMapping(value="/emp",method=RequestMethod.POST)
	 @ResponseBody
	  public Msg saveEmp(Employee employee) {
		 System.out.println("--------saveEmp----------");
		  int result = employeeService.saveEmp(employee);
		  System.out.println(result);
		  return  Msg.success().add("type", result);
	  }
		  
	
	@RequestMapping("/emps")
	@ResponseBody
	public Msg getEmpsWithJson(@RequestParam(value="pn",defaultValue="1") Integer pn,Model model) {
		System.out.println("------------------");
		PageHelper.startPage(pn, 5);
		List<Employee> emps = employeeService.getAll();
		System.out.println(emps);
		//ʹ��PageInfo���а�װ
		PageInfo page = new PageInfo(emps,5);
		return  Msg.success().add("pageInfo", page);
	}
    
	//��ѯԱ�������ݣ���ҳ��ѯ��
	//@RequestMapping("")
	public String getEmps(@RequestParam(value="pn",defaultValue="1") Integer pn,Model model) {
		
		System.out.println("------------------");
		PageHelper.startPage(pn, 5);
		
		
		List<Employee> emps = employeeService.getAll();
		System.out.println(emps);
		//ʹ��PageInfo���а�װ
		PageInfo page = new PageInfo(emps,5);
		model.addAttribute("pageInfo", page);
		return "list";
	}
	@RequestMapping("/haha")
	public String getTest2(Model model) {
		List<Employee> emps = employeeService.getAll();
		System.out.println(emps);
		model.addAttribute("haha", "haha");
		return "list";
	}
	

}
