package com.coderjin.ssm.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coderjin.ssm.crud.bean.Department;
import com.coderjin.ssm.crud.dao.DepartmentMapper;

@Service
public class DepartmentService {

	@Autowired
	private DepartmentMapper departmentMapper;
	
	//��ѯ���е�Ա��
	public List<Department> getAll(){
		System.out.println("---getAll----");
		return departmentMapper.selectByExample(null);
	}
	
}
